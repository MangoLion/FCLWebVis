# node.js-passport.js-template
A template for a node.js app using PostgresQL + Passport for authentication
Read all about it over here: https://medium.com/@timtamimi/getting-started-with-authentication-in-node-js-with-passport-and-postgresql-2219664b568c
